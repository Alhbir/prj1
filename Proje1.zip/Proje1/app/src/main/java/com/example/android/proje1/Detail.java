package com.example.android.proje1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;
import android.widget.TextView;

import com.example.android.proje1.pojos.Bilgiler;
import com.example.android.proje1.pojos.Image;
import com.daimajia.slider.library.Animations.DescriptionAnimation;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.TextSliderView;

import java.util.HashMap;

public class Detail extends AppCompatActivity {

    TextView titlePro;
    TextView pricePro;
    WebView webView;

    static Bilgiler bl;
    SliderLayout slider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        titlePro = findViewById(R.id.textTitle);
        pricePro = findViewById(R.id.textPrice);
        webView = findViewById(R.id.webView);
        titlePro.setText(bl.getProductName());
        pricePro.setText(bl.getPrice()+" TL");
        String webData = bl.getDescription();
        webView.loadData(webData, "text/html; charset=utf-8", "UTF-8");
        slider = findViewById(R.id.slider);
        //Log.d("titlePro",bl.getProductName());
        HashMap<String,String> url_maps = new HashMap<String, String>();
        if(bl.getImage()){
            int i =0;
            for(Image item : bl.getImages()) {
                url_maps.put(""+i,item.getNormal());
                i++;
            }
        }
        for(String name : url_maps.keySet()){
            TextSliderView textSliderView = new TextSliderView(this);
            // initialize a SliderLayout
            textSliderView
                    .description(name)
                    .image(url_maps.get(name))
                    .setScaleType(BaseSliderView.ScaleType.FitCenterCrop);

            //add your extra information
            textSliderView.bundle(new Bundle());
            textSliderView.getBundle()
                    .putString("extra",name);

            slider.addSlider(textSliderView);
        }
        slider.setPresetTransformer(SliderLayout.Transformer.Accordion);
        slider.setPresetIndicator(SliderLayout.PresetIndicators.Center_Bottom);
        slider.setCustomAnimation(new DescriptionAnimation());
        slider.setDuration(4000);

    }
}


