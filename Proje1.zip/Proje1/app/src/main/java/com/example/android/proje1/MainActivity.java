package com.example.android.proje1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.android.proje1.pojos.API;
import com.example.android.proje1.pojos.Bilgiler;
import com.example.android.proje1.pojos.ProdData;
import com.example.android.proje1.pojos.Services;
import com.squareup.picasso.Picasso;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    ListView proList;
    BaseAdapter urunBaseAdapter;
    LayoutInflater urunLayoutInflater;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        proList = findViewById(R.id.prodList);
        urunLayoutInflater = LayoutInflater.from(this);

        dataResult();
    }

    public void dataResult() {
        Services apiServis = API.getClient().create(Services.class);
        Call<ProdData> dt= apiServis.jsonData();
        dt.enqueue(new Callback<ProdData>() {
            @Override
            public void onResponse(Call<ProdData> call, Response<ProdData> response) {
                if(response.isSuccessful()){
                    List<Bilgiler> bl= response.body().getProducts().get(0).getBilgiler();
                    fetchRow(bl);
                }
            }

            @Override
            public void onFailure(Call<ProdData> call, Throwable t) {

            }
        });
    }

    private void fetchRow(final List<Bilgiler> bl) {
        /*for (Bilgiler item : bl) {
            Log.d("title", item.getProductName());
        }*/
        urunBaseAdapter =new BaseAdapter() {
            @Override
            public int getCount() {
                return bl.size();
            }

            @Override
            public Object getItem(int position) {
                return null;
            }

            @Override
            public long getItemId(int position) {
                return 0;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                if(convertView == null) {
                    convertView = urunLayoutInflater.inflate(R.layout.custom_row, null);
                }
                Bilgiler data = bl.get(position);
                ImageView img = convertView.findViewById(R.id.row_img);
                TextView title = convertView.findViewById(R.id.row_title);
                TextView desc = convertView.findViewById(R.id.row_desc);
                TextView price = convertView.findViewById(R.id.row_price);

                title.setText(data.getProductName());
                desc.setText(data.getBrief());
                price.setText(data.getPrice()+" TL");

                //image action
                if(data.getImage()) {
                    String thumb = data.getImages().get(0).getThumb();
                    Picasso.with(MainActivity.this).load(thumb).into(img);
                }
                return convertView;
            }
        };
        proList.setAdapter(urunBaseAdapter);
        proList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Detail.bl = bl.get(position);
                Intent ii= new Intent(MainActivity.this, Detail.class);
                startActivity(ii);
            }
        });
    }
}
