package com.example.android.proje1.pojos;


import retrofit2.Call;
import retrofit2.http.GET;

public interface Services {


    @GET("product.php?ref=3ed9209e2e113aa95774cf7117db20b8&start=0")
    Call<ProdData> jsonData();
}
